using System;

namespace hds{
	class script 
	{

		public script()
		{
			Output.WriteLine("TEST");
		}
		public void Test()
		{
			Console.WriteLine("TEST");
		}

	}
}